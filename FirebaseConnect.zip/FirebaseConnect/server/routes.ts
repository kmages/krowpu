import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertProjectSchema, insertPortfolioItemSchema, insertMessageSchema, insertConversationSchema, insertReportSchema, insertEscrowTransactionSchema, insertSubscriptionSchema } from "@shared/schema";
import { z } from "zod";
import Stripe from "stripe";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16",
});

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.get("/api/users/firebase/:uid", async (req, res) => {
    try {
      const { uid } = req.params;
      const user = await storage.getUserByFirebaseUid(uid);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Project routes
  app.get("/api/projects", async (req, res) => {
    try {
      const { buyerId, freelancerId } = req.query;
      let projects;
      
      if (buyerId) {
        projects = await storage.getProjectsByBuyer(Number(buyerId));
      } else if (freelancerId) {
        projects = await storage.getProjectsByFreelancer(Number(freelancerId));
      } else {
        projects = await storage.getAllProjects();
      }
      
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const projectData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(projectData);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid project data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Portfolio routes
  app.get("/api/portfolio/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const items = await storage.getPortfolioByUser(Number(userId));
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/portfolio", async (req, res) => {
    try {
      const portfolioData = insertPortfolioItemSchema.parse(req.body);
      const item = await storage.createPortfolioItem(portfolioData);
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid portfolio data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Conversation routes
  app.get("/api/conversations/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const conversations = await storage.getConversationsByUser(Number(userId));
      res.json(conversations);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/conversations", async (req, res) => {
    try {
      const conversationData = insertConversationSchema.parse(req.body);
      const conversation = await storage.createConversation(conversationData);
      res.status(201).json(conversation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid conversation data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Message routes
  app.get("/api/messages/:conversationId", async (req, res) => {
    try {
      const { conversationId } = req.params;
      const messages = await storage.getMessagesByConversation(Number(conversationId));
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      const message = await storage.createMessage(messageData);
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid message data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Admin routes
  app.get("/api/admin/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/admin/reports", async (req, res) => {
    try {
      const reports = await storage.getAllReports();
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/admin/reports/:id/resolve", async (req, res) => {
    try {
      const { id } = req.params;
      const { adminNotes, action } = req.body;
      const report = await storage.updateReport(Number(id), {
        status: "resolved",
        adminNotes,
        resolvedAt: new Date()
      });
      
      if (action === "deactivate_user" && report?.reportedUserId) {
        await storage.updateUser(report.reportedUserId, { isActive: false });
      }
      
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put("/api/admin/users/:id/status", async (req, res) => {
    try {
      const { id } = req.params;
      const { isActive } = req.body;
      const user = await storage.updateUser(Number(id), { isActive });
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Report routes
  app.post("/api/reports", async (req, res) => {
    try {
      const reportData = insertReportSchema.parse(req.body);
      const report = await storage.createReport(reportData);
      res.status(201).json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid report data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Escrow routes
  app.post("/api/escrow", async (req, res) => {
    try {
      const escrowData = insertEscrowTransactionSchema.parse(req.body);
      const transaction = await storage.createEscrowTransaction(escrowData);
      res.status(201).json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid escrow data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put("/api/escrow/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const transaction = await storage.updateEscrowTransaction(Number(id), updates);
      res.json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Stripe subscription routes
  app.post("/api/create-subscription", async (req, res) => {
    try {
      const { planType, userId } = req.body;
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      let amount, priceData;
      if (planType === "premium") {
        amount = 4999; // $49.99
        priceData = {
          currency: "usd",
          product_data: {
            name: "Krowpu Premium Subscription",
            description: "Unlimited messaging and premium features"
          },
          unit_amount: amount,
          recurring: { interval: "month" as const }
        };
      } else if (planType === "single_chat") {
        amount = 1999; // $19.99
        priceData = {
          currency: "usd",
          product_data: {
            name: "Single Chat Unlock",
            description: "Unlock messaging for one conversation"
          },
          unit_amount: amount
        };
      } else {
        return res.status(400).json({ message: "Invalid plan type" });
      }

      // Create Stripe customer if doesn't exist
      let customerId = user.stripeCustomerId;
      if (!customerId) {
        const customer = await stripe.customers.create({
          email: user.email,
          name: user.name,
        });
        customerId = customer.id;
        await storage.updateUser(userId, { stripeCustomerId: customerId });
      }

      // Create checkout session
      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        payment_method_types: ["card"],
        line_items: [{
          price_data: priceData,
          quantity: 1,
        }],
        mode: planType === "premium" ? "subscription" : "payment",
        success_url: `${req.headers.origin}/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${req.headers.origin}/cancel`,
        metadata: {
          userId: userId.toString(),
          planType
        }
      });

      res.json({ sessionId: session.id });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating subscription: " + error.message });
    }
  });

  // Stripe webhook
  app.post("/api/stripe/webhook", async (req, res) => {
    try {
      const event = req.body;

      switch (event.type) {
        case "checkout.session.completed":
          const session = event.data.object;
          const userId = parseInt(session.metadata.userId);
          const planType = session.metadata.planType;
          
          const subscriptionData = {
            userId,
            planType,
            amount: planType === "premium" ? 4999 : 1999,
            status: "active",
            stripeSubscriptionId: session.subscription || session.id
          };
          
          if (planType === "premium") {
            subscriptionData.endDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days
            await storage.updateUser(userId, { 
              subscriptionStatus: "premium",
              subscriptionExpiry: subscriptionData.endDate
            });
          } else {
            await storage.updateUser(userId, { subscriptionStatus: "single_chat" });
          }
          
          await storage.createSubscription(subscriptionData);
          break;
          
        case "customer.subscription.deleted":
          // Handle subscription cancellation
          break;
      }

      res.json({ received: true });
    } catch (error: any) {
      res.status(400).json({ message: "Webhook error: " + error.message });
    }
  });

  // Public portfolio routes
  app.get("/api/public/portfolio/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const user = await storage.getUser(Number(userId));
      const portfolio = await storage.getPortfolioByUser(Number(userId));
      const reviews = await storage.getReviewsByUser(Number(userId));
      
      if (!user || !user.isActive) {
        return res.status(404).json({ message: "Portfolio not found" });
      }

      const publicProfile = {
        name: user.name,
        avatar: user.avatar,
        role: user.role,
        rating: user.rating,
        responseTime: user.responseTime,
        successRate: user.successRate,
        totalEarned: user.totalEarned,
        portfolio,
        reviews: reviews.slice(0, 5) // Show only recent reviews
      };

      res.json(publicProfile);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
