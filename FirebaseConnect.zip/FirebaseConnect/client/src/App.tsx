import { Switch, Route, useLocation } from "wouter";
import { useState, useEffect } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import { AuthModal } from "@/components/auth-modal";
import Home from "@/pages/home";
import RoleSelection from "@/pages/role-selection";
import BuyerDashboard from "@/pages/buyer-dashboard";
import FreelancerDashboard from "@/pages/freelancer-dashboard";
import AdminDashboard from "@/pages/admin-dashboard";
import ChatInbox from "@/pages/chat-inbox";
import Subscription from "@/pages/subscription";
import PublicPortfolio from "@/pages/public-portfolio";
import NotFound from "@/pages/not-found";

function Router() {
  const { firebaseUser, user, loading, createUserProfile } = useAuth();
  const [location, setLocation] = useLocation();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showChatInbox, setShowChatInbox] = useState(false);

  useEffect(() => {
    if (firebaseUser && !user && !loading) {
      // User is authenticated but doesn't have a profile, show role selection
      setLocation("/role-selection");
    } else if (user) {
      // User has a profile, redirect to appropriate dashboard
      if (location === "/" || location === "/role-selection") {
        if (user.role === "buyer") {
          setLocation("/buyer-dashboard");
        } else if (user.role === "freelancer") {
          setLocation("/freelancer-dashboard");
        }
      }
    }
  }, [firebaseUser, user, loading, location, setLocation]);

  const handleRoleSelection = async (role: "buyer" | "freelancer") => {
    try {
      await createUserProfile(role);
      if (role === "buyer") {
        setLocation("/buyer-dashboard");
      } else {
        setLocation("/freelancer-dashboard");
      }
    } catch (error) {
      console.error("Error creating user profile:", error);
    }
  };

  const handleOpenMessages = () => {
    setShowChatInbox(true);
  };

  const handleCloseChatInbox = () => {
    setShowChatInbox(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (showChatInbox && user) {
    return <ChatInbox user={user} onClose={handleCloseChatInbox} />;
  }

  return (
    <Switch>
      <Route path="/">
        <Home onOpenAuth={() => setShowAuthModal(true)} />
        <AuthModal open={showAuthModal} onOpenChange={setShowAuthModal} />
      </Route>
      
      <Route path="/role-selection">
        {firebaseUser && !user ? (
          <RoleSelection onSelectRole={handleRoleSelection} />
        ) : (
          <NotFound />
        )}
      </Route>
      
      <Route path="/buyer-dashboard">
        {user && user.role === "buyer" ? (
          <BuyerDashboard user={user} onOpenMessages={handleOpenMessages} />
        ) : (
          <NotFound />
        )}
      </Route>
      
      <Route path="/freelancer-dashboard">
        {user && user.role === "freelancer" ? (
          <FreelancerDashboard user={user} onOpenMessages={handleOpenMessages} />
        ) : (
          <NotFound />
        )}
      </Route>
      
      <Route path="/admin-dashboard">
        {user && user.role === "admin" ? (
          <AdminDashboard user={user} onOpenMessages={handleOpenMessages} />
        ) : (
          <NotFound />
        )}
      </Route>
      
      <Route path="/subscription">
        {user ? (
          <Subscription user={user} />
        ) : (
          <NotFound />
        )}
      </Route>
      
      <Route path="/portfolio/:userId">
        {({ userId }) => <PublicPortfolio userId={userId} />}
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
