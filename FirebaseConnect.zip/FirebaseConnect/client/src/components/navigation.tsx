import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Bell, Mail, ChevronDown } from "lucide-react";
import { User } from "@shared/schema";

interface NavigationProps {
  user: User;
  onOpenMessages: () => void;
}

export function Navigation({ user, onOpenMessages }: NavigationProps) {
  const [location] = useLocation();

  const navItems = user.role === "admin"
    ? [
        { label: "Admin Dashboard", href: "/admin-dashboard" },
        { label: "Users", href: "/admin-dashboard" },
        { label: "Reports", href: "/admin-dashboard" },
      ]
    : user.role === "buyer" 
    ? [
        { label: "Dashboard", href: "/buyer-dashboard" },
        { label: "Find Freelancers", href: "/find-freelancers" },
        { label: "My Projects", href: "/my-projects" },
      ]
    : [
        { label: "Dashboard", href: "/freelancer-dashboard" },
        { label: "Find Work", href: "/find-work" },
        { label: "My Proposals", href: "/my-proposals" },
        { label: "Portfolio", href: "/portfolio" },
      ];

  return (
    <nav className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            <Link href="/">
              <h1 className="text-2xl font-bold text-primary">Krowpu</h1>
            </Link>
            <div className="hidden md:flex space-x-6">
              {navItems.map((item) => (
                <Link key={item.href} href={item.href}>
                  <span
                    className={`font-medium transition-colors ${
                      location === item.href
                        ? "text-primary"
                        : "text-gray-600 hover:text-primary"
                    }`}
                  >
                    {item.label}
                  </span>
                </Link>
              ))}
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {user.role === "buyer" && (
              <div className="bg-gray-100 px-4 py-2 rounded-lg">
                <span className="text-sm text-gray-600">Credits:</span>
                <span className="font-semibold text-primary ml-1">
                  ${user.credits?.toLocaleString()}
                </span>
              </div>
            )}
            
            {user.role !== "admin" && (user.subscriptionStatus === "free" || !user.subscriptionStatus) && (
              <Link href="/subscription">
                <Button variant="outline" size="sm" className="border-primary text-primary hover:bg-primary hover:text-white">
                  Upgrade
                </Button>
              </Link>
            )}
            
            {user.role === "freelancer" && (
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">Notifications</span>
                <div className="relative inline-flex items-center">
                  <input
                    type="checkbox"
                    checked={user.notificationsEnabled}
                    className="sr-only peer"
                    readOnly
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                </div>
              </div>
            )}
            
            <Button
              variant="ghost"
              size="sm"
              onClick={onOpenMessages}
              className="relative p-2"
            >
              <Mail className="h-5 w-5" />
              <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 bg-red-500 text-white text-xs">
                3
              </Badge>
            </Button>
            
            <div className="relative">
              <Button variant="ghost" className="flex items-center space-x-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.avatar || ""} alt={user.name} />
                  <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <span className="hidden md:block">{user.name}</span>
                <ChevronDown className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
