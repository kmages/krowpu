import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { X, Phone, Video, MoreVertical, Paperclip, Send } from "lucide-react";
import { User as UserType } from "@shared/schema";

interface ChatInboxProps {
  user: UserType;
  onClose: () => void;
}

export default function ChatInbox({ user, onClose }: ChatInboxProps) {
  const [selectedConversation, setSelectedConversation] = useState(0);
  const [messageInput, setMessageInput] = useState("");

  // Mock data for demonstration
  const conversations = [
    {
      id: 1,
      user: {
        name: "John Smith",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&w=40&h=40&fit=crop&crop=face",
        online: true,
      },
      project: {
        title: "Mobile App Design",
      },
      lastMessage: {
        content: "Thanks for the update on the project...",
        time: "2h",
      },
      unread: true,
    },
    {
      id: 2,
      user: {
        name: "Sarah Johnson",
        avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&w=40&h=40&fit=crop&crop=face",
        online: false,
      },
      project: {
        title: "Website Redesign",
      },
      lastMessage: {
        content: "Could we schedule a call to discuss...",
        time: "1d",
      },
      unread: false,
    },
  ];

  const messages = [
    {
      id: 1,
      senderId: user.id,
      content: "Hi John! I've completed the initial mockups for your mobile app. Would you like to schedule a call to review them?",
      time: "2:30 PM",
    },
    {
      id: 2,
      senderId: conversations[selectedConversation].id,
      content: "That sounds great! I'm available this afternoon. How about 4 PM?",
      time: "2:45 PM",
    },
    {
      id: 3,
      senderId: user.id,
      content: "Perfect! I'll send you the meeting link shortly.",
      time: "2:47 PM",
    },
    {
      id: 4,
      senderId: conversations[selectedConversation].id,
      content: "Thanks! Looking forward to seeing the progress.",
      time: "3:15 PM",
    },
  ];

  const handleSendMessage = () => {
    if (messageInput.trim()) {
      console.log("Sending message:", messageInput);
      setMessageInput("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Chat Sidebar */}
      <div className="w-1/3 bg-white border-r border-gray-200">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Messages</h2>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </div>
          <div className="mt-3">
            <Input placeholder="Search conversations..." />
          </div>
        </div>

        <div className="overflow-y-auto h-full">
          {conversations.map((conversation, index) => (
            <div
              key={conversation.id}
              onClick={() => setSelectedConversation(index)}
              className={`p-4 border-b border-gray-100 hover:bg-gray-50 cursor-pointer ${
                selectedConversation === index ? "bg-gray-50" : ""
              }`}
            >
              <div className="flex items-start space-x-3">
                <div className="relative">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={conversation.user.avatar} alt={conversation.user.name} />
                    <AvatarFallback>{conversation.user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div
                    className={`absolute -bottom-0 -right-0 w-3 h-3 rounded-full border-2 border-white ${
                      conversation.user.online ? "bg-green-500" : "bg-gray-400"
                    }`}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-medium text-gray-900 text-sm truncate">
                      {conversation.user.name}
                    </h3>
                    <span className="text-xs text-gray-500">{conversation.lastMessage.time}</span>
                  </div>
                  <p className="text-gray-600 text-sm truncate">
                    {conversation.lastMessage.content}
                  </p>
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-xs text-gray-500">{conversation.project.title}</span>
                    {conversation.unread && (
                      <div className="w-2 h-2 bg-primary rounded-full" />
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat Main */}
      <div className="flex-1 flex flex-col">
        {/* Chat Header */}
        <div className="bg-white border-b border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Avatar className="h-10 w-10">
                <AvatarImage 
                  src={conversations[selectedConversation].user.avatar} 
                  alt={conversations[selectedConversation].user.name} 
                />
                <AvatarFallback>
                  {conversations[selectedConversation].user.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-medium text-gray-900">
                  {conversations[selectedConversation].user.name}
                </h3>
                <p className="text-sm text-gray-600">
                  {conversations[selectedConversation].project.title} Project
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm">
                <Phone className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Video className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${
                message.senderId === user.id ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`max-w-xs lg:max-w-md rounded-lg p-3 ${
                  message.senderId === user.id
                    ? "bg-primary text-white"
                    : "bg-gray-200 text-gray-900"
                }`}
              >
                <p className="text-sm">{message.content}</p>
                <span
                  className={`text-xs block mt-1 ${
                    message.senderId === user.id
                      ? "text-primary-100"
                      : "text-gray-600"
                  }`}
                >
                  {message.time}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Chat Input */}
        <div className="bg-white border-t border-gray-200 p-4">
          <div className="flex items-center space-x-3">
            <Button variant="ghost" size="sm">
              <Paperclip className="h-4 w-4" />
            </Button>
            <Input
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              className="flex-1"
            />
            <Button onClick={handleSendMessage} className="bg-primary hover:bg-primary-dark">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
