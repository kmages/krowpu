import { useState } from "react";
import { Navigation } from "@/components/navigation";
import { FileUpload } from "@/components/file-upload";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Plus, Eye, Edit, Calendar, Star } from "lucide-react";
import { User as UserType } from "@shared/schema";

interface FreelancerDashboardProps {
  user: UserType;
  onOpenMessages: () => void;
}

export default function FreelancerDashboard({ user, onOpenMessages }: FreelancerDashboardProps) {
  const [showFileUpload, setShowFileUpload] = useState(false);

  // Mock data for demonstration
  const stats = {
    profileViews: 247,
    successRate: 96,
    responseTime: "2 hours",
    totalEarned: 18450,
  };

  const portfolioItems = [
    {
      id: 1,
      title: "E-commerce Website",
      description: "Modern responsive design",
      imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    },
    {
      id: 2,
      title: "Mobile App UI",
      description: "iOS & Android interface",
      imageUrl: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    },
  ];

  const activeProjects = [
    {
      id: 1,
      title: "Brand Identity Design",
      client: "TechStart Inc.",
      budget: 800,
      progress: 75,
      dueDate: "Dec 15, 2024",
    },
    {
      id: 2,
      title: "Website Redesign",
      client: "Local Restaurant",
      budget: 1200,
      progress: 45,
      dueDate: "Dec 28, 2024",
    },
  ];

  const reviews = [
    {
      id: 1,
      client: {
        name: "Mike Chen",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=40&h=40&fit=crop&crop=face",
      },
      rating: 5,
      comment: "Excellent work! Sarah delivered exactly what we needed. Highly recommended!",
      date: "2 days ago",
    },
    {
      id: 2,
      client: {
        name: "Lisa Wong",
        avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&w=40&h=40&fit=crop&crop=face",
      },
      rating: 4,
      comment: "Great communication and fast delivery. Will work with again!",
      date: "1 week ago",
    },
  ];

  const handleFileSelect = (files: File[]) => {
    console.log("Selected files:", files);
    // Handle file upload logic here
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-3 w-3 ${
          i < rating ? "text-yellow-400 fill-current" : "text-gray-300"
        }`}
      />
    ));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation user={user} onOpenMessages={onOpenMessages} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {user.name.split(" ")[0]}!
          </h1>
          <p className="text-gray-600">
            Manage your freelance business and showcase your work
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Portfolio Upload */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Portfolio</CardTitle>
                  <Button
                    onClick={() => setShowFileUpload(!showFileUpload)}
                    className="bg-primary hover:bg-primary-dark"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add Work
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {showFileUpload && (
                  <div className="mb-6">
                    <FileUpload onFileSelect={handleFileSelect} />
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {portfolioItems.map((item) => (
                    <div
                      key={item.id}
                      className="relative group rounded-lg overflow-hidden shadow-sm hover:shadow-lg transition-shadow"
                    >
                      <img
                        src={item.imageUrl}
                        alt={item.title}
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all flex items-center justify-center">
                        <div className="opacity-0 group-hover:opacity-100 transition-opacity space-x-2">
                          <Button size="sm" className="bg-white text-gray-900 hover:bg-gray-100">
                            <Eye className="mr-1 h-4 w-4" />
                            View
                          </Button>
                          <Button size="sm" className="bg-white text-gray-900 hover:bg-gray-100">
                            <Edit className="mr-1 h-4 w-4" />
                            Edit
                          </Button>
                        </div>
                      </div>
                      <div className="p-4">
                        <h4 className="font-medium text-gray-900 mb-1">{item.title}</h4>
                        <p className="text-gray-600 text-sm">{item.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Active Projects */}
            <Card>
              <CardHeader>
                <CardTitle>Active Projects</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activeProjects.map((project) => (
                    <div key={project.id} className="border border-gray-100 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h3 className="font-medium text-gray-900 mb-1">{project.title}</h3>
                          <p className="text-gray-600 text-sm">Client: {project.client}</p>
                        </div>
                        <span className="text-primary font-semibold">
                          ${project.budget.toLocaleString()}
                        </span>
                      </div>
                      <div className="mb-3">
                        <div className="flex justify-between text-sm text-gray-600 mb-1">
                          <span>Progress</span>
                          <span>{project.progress}%</span>
                        </div>
                        <Progress value={project.progress} className="h-2" />
                      </div>
                      <div className="flex justify-between items-center text-sm text-gray-500">
                        <span className="flex items-center">
                          <Calendar className="mr-1 h-4 w-4" />
                          Due: {project.dueDate}
                        </span>
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary-dark">
                          View Details
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Profile Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Profile Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Profile Views</span>
                    <span className="font-semibold">{stats.profileViews}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Success Rate</span>
                    <span className="font-semibold text-secondary">{stats.successRate}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Response Time</span>
                    <span className="font-semibold">{stats.responseTime}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Total Earned</span>
                    <span className="font-semibold text-primary">
                      ${stats.totalEarned.toLocaleString()}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Reviews Display */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg">Recent Reviews</CardTitle>
                  <div className="flex items-center space-x-1">
                    <span className="font-semibold">4.9</span>
                    <div className="flex">
                      {renderStars(5)}
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {reviews.map((review) => (
                    <div key={review.id} className="border-b border-gray-100 pb-4 last:border-b-0">
                      <div className="flex items-start space-x-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={review.client.avatar} alt={review.client.name} />
                          <AvatarFallback>{review.client.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <h4 className="font-medium text-gray-900 text-sm">
                              {review.client.name}
                            </h4>
                            <div className="flex">
                              {renderStars(review.rating)}
                            </div>
                          </div>
                          <p className="text-gray-600 text-sm mb-1">{review.comment}</p>
                          <span className="text-gray-400 text-xs">{review.date}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <Button variant="ghost" className="w-full text-primary hover:text-primary-dark text-sm mt-4">
                  View All Reviews
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
