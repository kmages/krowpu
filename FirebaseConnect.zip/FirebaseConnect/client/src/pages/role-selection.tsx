import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Search, Briefcase, Check } from "lucide-react";

interface RoleSelectionProps {
  onSelectRole: (role: "buyer" | "freelancer") => void;
}

export default function RoleSelection({ onSelectRole }: RoleSelectionProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary to-primary-dark flex items-center justify-center p-4">
      <Card className="max-w-4xl w-full">
        <CardContent className="p-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Choose Your Role
            </h2>
            <p className="text-gray-600 text-lg">
              How would you like to use Krowpu?
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card
              className="border-2 border-gray-200 hover:border-primary cursor-pointer transition-all hover:shadow-lg"
              onClick={() => onSelectRole("buyer")}
            >
              <CardContent className="p-8 text-center">
                <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-6">
                  <Search className="text-white text-3xl" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  I'm a Buyer
                </h3>
                <p className="text-gray-600 mb-6">
                  I want to hire freelancers for my projects
                </p>
                <ul className="text-left text-gray-600 space-y-2">
                  <li className="flex items-center">
                    <Check className="text-secondary mr-2 h-4 w-4" />
                    Post projects
                  </li>
                  <li className="flex items-center">
                    <Check className="text-secondary mr-2 h-4 w-4" />
                    Manage budgets
                  </li>
                  <li className="flex items-center">
                    <Check className="text-secondary mr-2 h-4 w-4" />
                    Review proposals
                  </li>
                  <li className="flex items-center">
                    <Check className="text-secondary mr-2 h-4 w-4" />
                    Track progress
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card
              className="border-2 border-gray-200 hover:border-secondary cursor-pointer transition-all hover:shadow-lg"
              onClick={() => onSelectRole("freelancer")}
            >
              <CardContent className="p-8 text-center">
                <div className="w-20 h-20 bg-secondary rounded-full flex items-center justify-center mx-auto mb-6">
                  <Briefcase className="text-white text-3xl" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  I'm a Freelancer
                </h3>
                <p className="text-gray-600 mb-6">
                  I want to offer my services and find work
                </p>
                <ul className="text-left text-gray-600 space-y-2">
                  <li className="flex items-center">
                    <Check className="text-secondary mr-2 h-4 w-4" />
                    Create portfolio
                  </li>
                  <li className="flex items-center">
                    <Check className="text-secondary mr-2 h-4 w-4" />
                    Submit proposals
                  </li>
                  <li className="flex items-center">
                    <Check className="text-secondary mr-2 h-4 w-4" />
                    Showcase skills
                  </li>
                  <li className="flex items-center">
                    <Check className="text-secondary mr-2 h-4 w-4" />
                    Earn money
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
