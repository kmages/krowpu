import { Button } from "@/components/ui/button";
import { Shield, Users, Rocket } from "lucide-react";

interface HomeProps {
  onOpenAuth: () => void;
}

export default function Home({ onOpenAuth }: HomeProps) {
  return (
    <div className="min-h-screen">
      {/* Navigation Header */}
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-primary">Krowpu</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={onOpenAuth}
                className="text-gray-600 hover:text-primary font-medium"
              >
                Sign In
              </Button>
              <Button
                onClick={onOpenAuth}
                className="bg-primary hover:bg-primary-dark text-white font-medium"
              >
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-primary to-primary-dark text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Find the Perfect{" "}
              <span className="text-emerald-300">Freelancer</span> for Your
              Project
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-emerald-100 max-w-3xl mx-auto">
              Connect with skilled professionals worldwide and bring your ideas
              to life
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                onClick={onOpenAuth}
                className="bg-white text-primary hover:bg-gray-100 font-semibold px-8 py-4 text-lg"
              >
                <Users className="mr-2 h-5 w-5" />
                Hire a Freelancer
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={onOpenAuth}
                className="border-2 border-white text-white hover:bg-white hover:text-primary font-semibold px-8 py-4 text-lg"
              >
                <Rocket className="mr-2 h-5 w-5" />
                Become a Freelancer
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose Krowpu?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              We make it easy to connect, collaborate, and get work done
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8 rounded-xl bg-gray-50 hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield className="text-white text-2xl" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Secure & Trusted</h3>
              <p className="text-gray-600">
                Advanced security measures and verified profiles ensure safe
                transactions
              </p>
            </div>
            <div className="text-center p-8 rounded-xl bg-gray-50 hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="text-white text-2xl" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Global Talent</h3>
              <p className="text-gray-600">
                Access skilled professionals from around the world in various
                fields
              </p>
            </div>
            <div className="text-center p-8 rounded-xl bg-gray-50 hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-warning rounded-full flex items-center justify-center mx-auto mb-6">
                <Rocket className="text-white text-2xl" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Fast Delivery</h3>
              <p className="text-gray-600">
                Get your projects completed quickly with our efficient workflow
                system
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
