import { Navigation } from "@/components/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, CreditCard, ProjectorIcon, DollarSign, CheckCircle, Star, Clock, User, ChevronRight } from "lucide-react";
import { User as UserType } from "@shared/schema";

interface BuyerDashboardProps {
  user: UserType;
  onOpenMessages: () => void;
}

export default function BuyerDashboard({ user, onOpenMessages }: BuyerDashboardProps) {
  // Mock data for demonstration
  const stats = {
    activeProjects: 4,
    totalSpent: 12450,
    completedProjects: 15,
    successRate: 98,
  };

  const recentProjects = [
    {
      id: 1,
      title: "Mobile App UI Design",
      description: "Modern mobile application interface design for iOS and Android",
      budget: 1200,
      status: "in_progress",
      proposals: 3,
      createdAt: "2 days ago",
    },
    {
      id: 2,
      title: "E-commerce Website Development",
      description: "Full-stack e-commerce platform with payment integration",
      budget: 3500,
      status: "completed",
      proposals: 8,
      createdAt: "1 week ago",
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "in_progress":
        return "bg-yellow-500";
      case "completed":
        return "bg-green-500";
      case "active":
        return "bg-blue-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "in_progress":
        return "In Progress";
      case "completed":
        return "Completed";
      case "active":
        return "Active";
      default:
        return status;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation user={user} onOpenMessages={onOpenMessages} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {user.name.split(" ")[0]}!
          </h1>
          <p className="text-gray-600">
            Manage your projects and find the perfect freelancers
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Button
            size="lg"
            className="bg-primary hover:bg-primary-dark text-white p-6 h-auto text-left justify-start"
          >
            <div>
              <Plus className="text-2xl mb-3" />
              <h3 className="text-lg font-semibold mb-2">Post a Project</h3>
              <p className="text-primary-100">Find freelancers for your next project</p>
            </div>
          </Button>
          <Button
            size="lg"
            className="bg-secondary hover:bg-emerald-700 text-white p-6 h-auto text-left justify-start"
          >
            <div>
              <Search className="text-2xl mb-3" />
              <h3 className="text-lg font-semibold mb-2">Browse Freelancers</h3>
              <p className="text-emerald-100">Discover talented professionals</p>
            </div>
          </Button>
          <Button
            size="lg"
            className="bg-orange-600 hover:bg-orange-700 text-white p-6 h-auto text-left justify-start"
          >
            <div>
              <CreditCard className="text-2xl mb-3" />
              <h3 className="text-lg font-semibold mb-2">Add Credits</h3>
              <p className="text-orange-100">Top up your account balance</p>
            </div>
          </Button>
        </div>

        {/* Recent Projects */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-xl">Recent Projects</CardTitle>
              <Button variant="ghost" className="text-primary hover:text-primary-dark">
                View All
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentProjects.map((project) => (
                <div
                  key={project.id}
                  className="flex items-center justify-between p-4 border border-gray-100 rounded-lg hover:shadow-sm transition-shadow"
                >
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-900 mb-1">{project.title}</h3>
                    <p className="text-gray-600 text-sm mb-2">{project.description}</p>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span className="flex items-center">
                        <Clock className="mr-1 h-4 w-4" />
                        Posted {project.createdAt}
                      </span>
                      <span className="flex items-center">
                        <User className="mr-1 h-4 w-4" />
                        {project.proposals} proposals
                      </span>
                      <span className="text-primary font-medium">
                        ${project.budget.toLocaleString()}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge className={`${getStatusColor(project.status)} text-white`}>
                      {getStatusText(project.status)}
                    </Badge>
                    <Button variant="ghost" size="sm">
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-gray-600">Active Projects</h3>
                <ProjectorIcon className="text-primary h-5 w-5" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{stats.activeProjects}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-gray-600">Total Spent</h3>
                <DollarSign className="text-secondary h-5 w-5" />
              </div>
              <p className="text-2xl font-bold text-gray-900">
                ${stats.totalSpent.toLocaleString()}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-gray-600">Completed</h3>
                <CheckCircle className="text-secondary h-5 w-5" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{stats.completedProjects}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-gray-600">Success Rate</h3>
                <Star className="text-orange-500 h-5 w-5" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{stats.successRate}%</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
