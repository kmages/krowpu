import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star, Clock, TrendingUp, Eye, ExternalLink } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";

interface PublicPortfolioProps {
  userId: string;
}

export default function PublicPortfolio({ userId }: PublicPortfolioProps) {
  const [, setLocation] = useLocation();

  const { data: profile, isLoading, error } = useQuery({
    queryKey: ["/api/public/portfolio", userId],
    queryFn: () => apiRequest("GET", `/api/public/portfolio/${userId}`).then(res => res.json()),
    enabled: !!userId
  });

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating / 10);
    const hasHalfStar = (rating % 10) >= 5;
    
    for (let i = 0; i < 5; i++) {
      if (i < fullStars) {
        stars.push(
          <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
        );
      } else if (i === fullStars && hasHalfStar) {
        stars.push(
          <Star key={i} className="h-4 w-4 text-yellow-400 fill-current opacity-50" />
        );
      } else {
        stars.push(
          <Star key={i} className="h-4 w-4 text-gray-300" />
        );
      }
    }
    return stars;
  };

  const handleContactFreelancer = () => {
    // Redirect to sign up or subscription page
    setLocation("/role-selection");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Portfolio Not Found</h2>
          <p className="text-gray-600">This freelancer's portfolio is not available.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-primary cursor-pointer" onClick={() => setLocation("/")}>
                Krowpu
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => setLocation("/")}>
                Browse Freelancers
              </Button>
              <Button onClick={() => setLocation("/role-selection")}>
                Join Krowpu
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-8 mb-8">
          <div className="flex items-start space-x-6">
            <Avatar className="h-24 w-24">
              <AvatarImage src={profile.avatar || ""} alt={profile.name} />
              <AvatarFallback className="text-2xl">{profile.name.charAt(0)}</AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">{profile.name}</h1>
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="flex items-center">
                      {renderStars(profile.rating || 0)}
                      <span className="ml-2 text-sm text-gray-600">
                        {((profile.rating || 0) / 10).toFixed(1)}
                      </span>
                    </div>
                    <Badge className="bg-purple-500 text-white">
                      {profile.role === "freelancer" ? "Freelancer" : "Professional"}
                    </Badge>
                  </div>
                </div>
                
                <Button 
                  size="lg" 
                  className="bg-primary hover:bg-primary-dark"
                  onClick={handleContactFreelancer}
                >
                  Contact {profile.name.split(" ")[0]}
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="flex items-center space-x-2">
                  <Clock className="h-5 w-5 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-600">Response Time</p>
                    <p className="font-semibold">{profile.responseTime || "2 hours"}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-green-500" />
                  <div>
                    <p className="text-sm text-gray-600">Success Rate</p>
                    <p className="font-semibold text-green-600">{profile.successRate || 0}%</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Eye className="h-5 w-5 text-blue-500" />
                  <div>
                    <p className="text-sm text-gray-600">Total Earned</p>
                    <p className="font-semibold text-blue-600">
                      ${(profile.totalEarned || 0).toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Portfolio */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Portfolio</CardTitle>
              </CardHeader>
              <CardContent>
                {profile.portfolio && profile.portfolio.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {profile.portfolio.map((item: any) => (
                      <div key={item.id} className="group">
                        <div className="relative overflow-hidden rounded-lg bg-gray-200 aspect-video">
                          {item.imageUrl ? (
                            <img
                              src={item.imageUrl}
                              alt={item.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <ExternalLink className="h-12 w-12 text-gray-400" />
                            </div>
                          )}
                        </div>
                        <div className="mt-4">
                          <h3 className="font-semibold text-gray-900 mb-1">{item.title}</h3>
                          {item.description && (
                            <p className="text-gray-600 text-sm">{item.description}</p>
                          )}
                          {item.projectUrl && (
                            <a
                              href={item.projectUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center text-primary hover:text-primary-dark text-sm mt-2"
                            >
                              View Project <ExternalLink className="ml-1 h-3 w-3" />
                            </a>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <ExternalLink className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No portfolio items available</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Reviews */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Recent Reviews</CardTitle>
              </CardHeader>
              <CardContent>
                {profile.reviews && profile.reviews.length > 0 ? (
                  <div className="space-y-6">
                    {profile.reviews.map((review: any) => (
                      <div key={review.id} className="border-b border-gray-100 pb-4 last:border-b-0">
                        <div className="flex items-start space-x-3">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback>
                              {review.reviewerName ? review.reviewerName.charAt(0) : "U"}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-1">
                              <div className="flex">
                                {renderStars(review.rating * 10)}
                              </div>
                              <span className="text-xs text-gray-500">
                                {new Date(review.createdAt).toLocaleDateString()}
                              </span>
                            </div>
                            <p className="text-gray-700 text-sm">{review.comment}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Star className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-600">No reviews yet</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Contact CTA */}
            <Card className="mt-6">
              <CardContent className="p-6 text-center">
                <h3 className="font-semibold text-gray-900 mb-2">
                  Ready to work with {profile.name.split(" ")[0]}?
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  Join Krowpu to start a conversation and hire this talented freelancer.
                </p>
                <Button 
                  className="w-full"
                  onClick={handleContactFreelancer}
                >
                  Get Started
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}