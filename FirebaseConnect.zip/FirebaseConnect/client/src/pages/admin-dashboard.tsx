import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Navigation } from "@/components/navigation";
import { apiRequest } from "@/lib/queryClient";
import { User as UserType, Report } from "@shared/schema";
import { AlertTriangle, Users, Flag, CheckCircle, X, Ban } from "lucide-react";

interface AdminDashboardProps {
  user: UserType;
  onOpenMessages: () => void;
}

export default function AdminDashboard({ user, onOpenMessages }: AdminDashboardProps) {
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [adminNotes, setAdminNotes] = useState("");
  const [resolveAction, setResolveAction] = useState("");
  const queryClient = useQueryClient();

  const { data: users = [] } = useQuery({
    queryKey: ["/api/admin/users"],
    queryFn: () => apiRequest("GET", "/api/admin/users").then(res => res.json())
  });

  const { data: reports = [] } = useQuery({
    queryKey: ["/api/admin/reports"],
    queryFn: () => apiRequest("GET", "/api/admin/reports").then(res => res.json())
  });

  const resolveReportMutation = useMutation({
    mutationFn: ({ reportId, notes, action }: { reportId: number; notes: string; action: string }) =>
      apiRequest("POST", `/api/admin/reports/${reportId}/resolve`, { adminNotes: notes, action }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/reports"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setSelectedReport(null);
      setAdminNotes("");
      setResolveAction("");
    }
  });

  const updateUserStatusMutation = useMutation({
    mutationFn: ({ userId, isActive }: { userId: number; isActive: boolean }) =>
      apiRequest("PUT", `/api/admin/users/${userId}/status`, { isActive }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    }
  });

  const stats = {
    totalUsers: users.length,
    activeUsers: users.filter((u: UserType) => u.isActive).length,
    pendingReports: reports.filter((r: Report) => r.status === "pending").length,
    freelancers: users.filter((u: UserType) => u.role === "freelancer").length,
  };

  const getReportStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge className="bg-yellow-500 text-white">Pending</Badge>;
      case "resolved":
        return <Badge className="bg-green-500 text-white">Resolved</Badge>;
      case "dismissed":
        return <Badge className="bg-gray-500 text-white">Dismissed</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getUserRoleBadge = (role: string) => {
    switch (role) {
      case "buyer":
        return <Badge className="bg-blue-500 text-white">Buyer</Badge>;
      case "freelancer":
        return <Badge className="bg-purple-500 text-white">Freelancer</Badge>;
      case "admin":
        return <Badge className="bg-red-500 text-white">Admin</Badge>;
      default:
        return <Badge>{role}</Badge>;
    }
  };

  const handleResolveReport = () => {
    if (!selectedReport) return;
    
    resolveReportMutation.mutate({
      reportId: selectedReport.id,
      notes: adminNotes,
      action: resolveAction
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation user={user} onOpenMessages={onOpenMessages} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
          <p className="text-gray-600">Manage users, reports, and platform oversight</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-gray-600">Total Users</h3>
                <Users className="text-primary h-5 w-5" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{stats.totalUsers}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-gray-600">Active Users</h3>
                <CheckCircle className="text-green-500 h-5 w-5" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{stats.activeUsers}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-gray-600">Pending Reports</h3>
                <AlertTriangle className="text-yellow-500 h-5 w-5" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{stats.pendingReports}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-gray-600">Freelancers</h3>
                <Flag className="text-purple-500 h-5 w-5" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{stats.freelancers}</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Reports Management */}
          <Card>
            <CardHeader>
              <CardTitle>Reports Management</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {reports.map((report: Report) => (
                  <div
                    key={report.id}
                    className="flex items-center justify-between p-4 border border-gray-100 rounded-lg hover:shadow-sm transition-shadow"
                  >
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900 mb-1">{report.reason}</h3>
                      <p className="text-gray-600 text-sm mb-2">{report.description}</p>
                      <div className="flex items-center space-x-2">
                        {getReportStatusBadge(report.status)}
                        <span className="text-xs text-gray-500">
                          {new Date(report.createdAt!).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                    {report.status === "pending" && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedReport(report)}
                      >
                        Review
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* User Management */}
          <Card>
            <CardHeader>
              <CardTitle>User Management</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {users.map((u: UserType) => (
                  <div
                    key={u.id}
                    className="flex items-center justify-between p-4 border border-gray-100 rounded-lg"
                  >
                    <div className="flex items-center space-x-3">
                      <img
                        src={u.avatar || `https://ui-avatars.com/api/?name=${u.name}&background=random`}
                        alt={u.name}
                        className="w-10 h-10 rounded-full"
                      />
                      <div>
                        <h3 className="font-medium text-gray-900">{u.name}</h3>
                        <p className="text-gray-600 text-sm">{u.email}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          {getUserRoleBadge(u.role)}
                          {!u.isActive && <Badge className="bg-red-500 text-white">Inactive</Badge>}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant={u.isActive ? "destructive" : "default"}
                        size="sm"
                        onClick={() => updateUserStatusMutation.mutate({
                          userId: u.id,
                          isActive: !u.isActive
                        })}
                        disabled={updateUserStatusMutation.isPending}
                      >
                        {u.isActive ? <Ban className="h-4 w-4" /> : <CheckCircle className="h-4 w-4" />}
                        {u.isActive ? "Deactivate" : "Activate"}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Report Resolution Dialog */}
      <Dialog open={!!selectedReport} onOpenChange={() => setSelectedReport(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Resolve Report</DialogTitle>
          </DialogHeader>
          
          {selectedReport && (
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-gray-900 mb-2">Report Details</h3>
                <p className="text-sm text-gray-600 mb-1">
                  <strong>Reason:</strong> {selectedReport.reason}
                </p>
                <p className="text-sm text-gray-600 mb-1">
                  <strong>Description:</strong> {selectedReport.description}
                </p>
                <p className="text-sm text-gray-600">
                  <strong>Reported:</strong> {new Date(selectedReport.createdAt!).toLocaleDateString()}
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Action
                </label>
                <Select value={resolveAction} onValueChange={setResolveAction}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select action" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dismiss">Dismiss Report</SelectItem>
                    <SelectItem value="warn_user">Warn User</SelectItem>
                    <SelectItem value="deactivate_user">Deactivate User</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Admin Notes
                </label>
                <Textarea
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  placeholder="Add notes about the resolution..."
                  rows={3}
                />
              </div>

              <div className="flex justify-end space-x-2">
                <Button
                  variant="ghost"
                  onClick={() => setSelectedReport(null)}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleResolveReport}
                  disabled={!resolveAction || resolveReportMutation.isPending}
                >
                  Resolve Report
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}