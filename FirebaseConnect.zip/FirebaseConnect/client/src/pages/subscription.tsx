import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Crown, MessageSquare } from "lucide-react";
import { User as UserType } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { loadStripe } from "@stripe/stripe-js";

if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface SubscriptionProps {
  user: UserType;
}

export default function Subscription({ user }: SubscriptionProps) {
  const [loading, setLoading] = useState<string | null>(null);

  const handleSubscribe = async (planType: "premium" | "single_chat") => {
    try {
      setLoading(planType);
      
      const response = await apiRequest("POST", "/api/create-subscription", {
        planType,
        userId: user.id
      });
      
      const { sessionId } = await response.json();
      
      const stripe = await stripePromise;
      if (!stripe) throw new Error("Stripe failed to load");
      
      await stripe.redirectToCheckout({ sessionId });
    } catch (error) {
      console.error("Subscription error:", error);
      setLoading(null);
    }
  };

  const plans = [
    {
      id: "premium",
      name: "Premium",
      price: "$49.99",
      period: "/month",
      description: "Unlimited messaging and premium features",
      features: [
        "Unlimited conversations",
        "Priority support",
        "Advanced portfolio features",
        "Analytics dashboard",
        "Early access to new features"
      ],
      icon: Crown,
      popular: true
    },
    {
      id: "single_chat",
      name: "Single Chat",
      price: "$19.99",
      period: "one-time",
      description: "Unlock messaging for one conversation",
      features: [
        "Message one freelancer/buyer",
        "Full conversation history",
        "File sharing",
        "No time limit"
      ],
      icon: MessageSquare,
      popular: false
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Choose Your Plan
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Unlock the full potential of Krowpu with our flexible subscription options
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {plans.map((plan) => {
            const Icon = plan.icon;
            return (
              <Card
                key={plan.id}
                className={`relative border-2 ${
                  plan.popular
                    ? "border-primary shadow-lg"
                    : "border-gray-200"
                } hover:shadow-xl transition-shadow`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-primary text-white px-4 py-1">
                      Most Popular
                    </Badge>
                  </div>
                )}
                
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                    plan.popular ? "bg-primary" : "bg-gray-100"
                  }`}>
                    <Icon className={`w-8 h-8 ${
                      plan.popular ? "text-white" : "text-gray-600"
                    }`} />
                  </div>
                  
                  <CardTitle className="text-2xl font-bold text-gray-900">
                    {plan.name}
                  </CardTitle>
                  
                  <div className="mt-4">
                    <span className="text-4xl font-bold text-primary">
                      {plan.price}
                    </span>
                    <span className="text-gray-600 ml-1">
                      {plan.period}
                    </span>
                  </div>
                  
                  <p className="text-gray-600 mt-2">
                    {plan.description}
                  </p>
                </CardHeader>
                
                <CardContent>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center">
                        <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button
                    className={`w-full ${
                      plan.popular
                        ? "bg-primary hover:bg-primary-dark"
                        : "bg-gray-900 hover:bg-gray-800"
                    } text-white`}
                    size="lg"
                    onClick={() => handleSubscribe(plan.id as "premium" | "single_chat")}
                    disabled={loading === plan.id}
                  >
                    {loading === plan.id ? "Processing..." : `Get ${plan.name}`}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-600">
            All plans include secure payments and can be cancelled anytime.
          </p>
          <p className="text-sm text-gray-500 mt-2">
            Prices are in USD. By subscribing, you agree to our Terms of Service.
          </p>
        </div>
      </div>
    </div>
  );
}