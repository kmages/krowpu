import { useState, useEffect } from "react";
import { User as FirebaseUser } from "firebase/auth";
import { onAuthStateChangedListener, handleRedirectResult } from "@/lib/firebase";
import { User } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export function useAuth() {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Handle redirect result on page load
    handleRedirectResult()
      .then((result) => {
        if (result?.user) {
          // User signed in via redirect
          handleAuthUser(result.user);
        }
      })
      .catch((error) => {
        console.error("Error handling redirect result:", error);
      });

    // Set up auth state listener
    const unsubscribe = onAuthStateChangedListener(async (firebaseUser) => {
      setFirebaseUser(firebaseUser);
      if (firebaseUser) {
        await handleAuthUser(firebaseUser);
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleAuthUser = async (firebaseUser: FirebaseUser) => {
    try {
      // Check if user exists in our database
      const response = await apiRequest("GET", `/api/users/firebase/${firebaseUser.uid}`);
      const userData = await response.json();
      setUser(userData);
    } catch (error) {
      // User doesn't exist, they need to complete profile setup
      setUser(null);
    }
  };

  const createUserProfile = async (role: "buyer" | "freelancer") => {
    if (!firebaseUser) return;

    try {
      const userData = {
        firebaseUid: firebaseUser.uid,
        email: firebaseUser.email!,
        name: firebaseUser.displayName || firebaseUser.email!.split("@")[0],
        role,
        avatar: firebaseUser.photoURL,
        credits: role === "buyer" ? 2500 : 0,
      };

      const response = await apiRequest("POST", "/api/users", userData);
      const newUser = await response.json();
      setUser(newUser);
      return newUser;
    } catch (error) {
      console.error("Error creating user profile:", error);
      throw error;
    }
  };

  return {
    firebaseUser,
    user,
    loading,
    createUserProfile,
  };
}
